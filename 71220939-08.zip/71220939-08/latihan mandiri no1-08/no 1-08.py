teks_1 = input("Masukkan file ke 1 : ")
teks_2 = input("Masukkan file ke 2 : ")

handle = open(teks_1, "r")
handle_2 = open(teks_2, "r")

handle_2 = handle_2.read()
handle_2_list = handle_2.split("\n")
sebuah_baris = 0

for y in handle :
    sebuah_baris += 1

    if y.rstrip() == handle_2_list[sebuah_baris-1]:
        continue
    else:
        print("Perbedaan pada baris {}" .format(sebuah_baris))

handle.close()
