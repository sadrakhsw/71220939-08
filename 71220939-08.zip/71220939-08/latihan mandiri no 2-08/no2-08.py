sebuah_file = input(" Masukkan nama soal : ")

file = open(sebuah_file, "r")

for i in file:
    i = i.split(" || ")
    print(i[0])
    jawab = input("jawab : ")
    if jawab.lower() == i[1].lower().strip("\n"):
        print("jawaban benar!")
    else:
        print("jawaban salah!")